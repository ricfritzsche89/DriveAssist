# Drive Check

Progressive Web App für Strecken-, Verkehrs- und Tankstellenübersicht in Deutschland und Tschechien.
Läuft vollständig kostenlos, ohne eigenen Server, ohne Konto, gehostet auf GitHub Pages.

**Status: Alle 12 Phasen umgesetzt und getestet.**

## 1. Installation (lokal)

Kein Build-Prozess nötig. Einfach einen statischen Webserver im Projektordner starten:

```bash
npx serve .
# oder
python3 -m http.server 8080
```

Danach `http://localhost:8080` im Browser öffnen. Service Worker und IndexedDB benötigen
`http://localhost` oder `https://` — nicht `file://`.

## 2. GitHub-Repository einrichten

```bash
git init
git add .
git commit -m "Drive Check – vollständige Version"
git branch -M main
git remote add origin https://github.com/<dein-nutzername>/<dein-repo>.git
git push -u origin main
```

## 3. GitHub Pages aktivieren

1. Im Repository: **Settings → Pages**
2. **Source**: „Deploy from a branch“
3. **Branch**: `main`, Ordner `/ (root)`
4. Speichern — die App ist danach unter `https://<nutzername>.github.io/<repo>/` erreichbar.

Alle Pfade sind relativ (`./`), die App funktioniert daher auch in einem Unterordner.

## 4. API-Konfiguration

| Was | Wo eintragen | Pflicht? |
|---|---|---|
| Tankerkönig-API-Key (DE-Tankstellenpreise) | App → Einstellungen → API-Zugänge | Nur für die DE-Tankstellensuche/-preise |

Kostenlosen Tankerkönig-Key anfordern: https://creativecommons.tankerkoenig.de/ (einfaches
Formular, keine Kreditkarte). Alle anderen Datenquellen (Autobahn GmbH, Nominatim, OSRM,
OpenStreetMap-Kacheln) benötigen keinen Schlüssel.

## 5. Datenquellen & Lizenzen

| Bereich | Anbieter | URL | Kosten | API-Key | CORS | Attribution |
|---|---|---|---|---|---|---|
| Verkehr DE | Autobahn GmbH | verkehr.autobahn.de/o/autobahn | kostenlos | nein | ja | amtliche Daten, freie Nutzung |
| Verkehr CZ | — | — | — | — | — | **nicht angebunden**, siehe Abschnitt 6 |
| Kraftstoff DE | Tankerkönig / MTS-K | creativecommons.tankerkoenig.de | kostenlos | ja (kostenlos) | ja | „Tankerkönig“ + Link erforderlich |
| Kraftstoff CZ | — | — | — | — | — | **nicht angebunden**, siehe Abschnitt 6 – manuelle Erfassung als Fallback |
| Geocoding | Nominatim (OSM) | nominatim.openstreetmap.org | kostenlos | nein | ja | © OpenStreetMap-Mitwirkende; Nutzungsrichtlinie: max. 1 Anfrage/s, kein Bulk |
| Routing | OSRM Public Demo | router.project-osrm.org | kostenlos | nein | ja | nur für geringe/private Nutzung gedacht, keine SLA |
| Kartenkacheln | OpenStreetMap | tile.openstreetmap.org | kostenlos | nein | ja | © OpenStreetMap-Mitwirkende (in der Karte eingeblendet) |
| Kartenbibliothek | Leaflet | cdnjs.cloudflare.com | kostenlos | nein | ja | BSD-2-Clause |

Alle Aufrufe laufen direkt aus dem Browser (clientseitig) — kein eigener Server nötig,
konform zur Kostenregel des Projekts.

## 6. Warum keine Live-Daten für Tschechien?

**Verkehr:** Der offizielle tschechische Feed (NDIC/registr.dopravniinfo.cz) liefert DATEX-II-
und DDR-XML-Daten zwar kostenlos, aber nur nach Registrierung UND per Push an einen selbst
betriebenen, öffentlich erreichbaren Server. Das widerspricht der Kernvorgabe „kein eigener
Server“ dieses Projekts und ist aus einer statischen GitHub-Pages-PWA heraus nicht per
einfachem GET-Aufruf nutzbar. Es wurde deshalb bewusst keine Verkehrsquelle für Tschechien
eingebunden (siehe `js/providers/traffic-cz.js` für Details und mögliche Alternativen).

**Tankstellen:** Fuelo.net bietet laut eigener Aussage einen kostenlosen API-Key auf Anfrage
(fuelo.net/about/api_key_request), aber zum Zeitpunkt der Erstellung dieser App ließ sich keine
verlässliche, öffentlich dokumentierte Schnittstellenbeschreibung (Endpunkte, Antwortformat)
finden. BenzinMapa.cz und mBenzin.cz bieten keine offiziell dokumentierte freie REST-API —
ein Zugriff wäre nur per Scraping möglich, was die Vorgabe „niemals ungeprüft scrapen“
ausdrücklich verbietet. Als ehrlicher Fallback können CZ-Tankstellen-Favoriten daher manuell
mit ihren Preisen angelegt werden (Tanken → CZ-Favorit manuell anlegen). Die Provider-Datei
`js/providers/fuel-cz.js` ist bereits so gebaut, dass eine echte Fuelo-Anbindung jederzeit
nachgerüstet werden kann, sobald ein Key + verifizierte Doku vorliegen — ohne den Rest der App
anzufassen (Primär-/Fallback-Architektur).

## 7. Lokale Entwicklung — Projektstruktur

```
drive-check/
├── index.html
├── manifest.json
├── service-worker.js
├── css/
│   └── styles.css
├── js/
│   ├── app.js              # Router, Views, Dashboard/Strecken/Tanken/Einstellungen-Logik
│   ├── db.js                # IndexedDB-Wrapper (routes, waypoints, fuelStations, fuelFavorites, trafficCache, settings)
│   ├── geo.js                # Distanz-/Korridor-Berechnung, Gesamtstatus-Aggregation
│   ├── routing.js            # Geocoding (Nominatim) + Routing (OSRM)
│   ├── map.js                # Leaflet-Wrapper (lazy-loaded), Marker-Kategorien
│   ├── notify.js             # optionale PWA-Benachrichtigungen
│   └── providers/
│       ├── traffic-de.js     # Autobahn GmbH API
│       ├── traffic-cz.js     # dokumentierter Stub (siehe Abschnitt 6)
│       ├── fuel-de.js        # Tankerkönig API
│       └── fuel-cz.js        # Primär/Fallback-Stub + manuelle Preiserfassung
└── icons/                     # PWA-Icons (72–512px)
```

## 8. PWA-Installation auf Android

1. Seite in Chrome öffnen (über die echte GitHub-Pages-URL, nicht lokal ohne HTTPS).
2. Menü (⋮) → „App installieren“ bzw. Banner „Zum Startbildschirm hinzufügen“ antippen.
3. App erscheint mit eigenem Icon auf dem Startbildschirm und startet ohne Browser-UI.
4. Beim ersten Öffnen wird die App-Shell automatisch für Offline-Nutzung gecacht.

## 9. Funktionsüberblick

- **Dashboard**: zeigt die Standardstrecke mit Live-Ampelstatus (🟢🟡🟠🔴⚪), Fahrzeit,
  Distanz und Tankstellen-Favoriten mit aktuellen Preisen.
- **Meine Strecken**: Anlegen/Bearbeiten/Löschen mit Orts-Autovervollständigung
  (Nominatim), automatischer Routenberechnung (OSRM) inkl. Kartenvorschau, einstellbarem
  Verkehrskorridor (250–2000 m).
- **Karte**: Übersicht über alle Strecken, Start-/Zielpunkte und Tankstellen-Favoriten;
  „Mein Standort“-Button (GPS nur nach expliziter Freigabe).
- **Tanken**: DE-Tankstellensuche in der Nähe (Tankerkönig) mit Favoriten-Speicherung;
  CZ-Favoriten manuell mit Preisen anlegen.
- **Einstellungen**: Standardstrecke, Verkehrskorridor, Tankerkönig-API-Key, Einheiten,
  Benachrichtigungen, Datenexport/-import (JSON-Backup), Cache leeren.
- **Offline**: App-Shell komplett offline nutzbar; bei fehlender Verbindung wird der
  Streckenstatus ehrlich als „⚪ Status unbekannt – Offline“ angezeigt statt veralteter
  Daten als aktuell auszugeben.

## 10. Bekannte Einschränkungen

- Verkehr und Tankstellenpreise für Tschechien sind mangels verifizierter freier API nicht
  live verfügbar (siehe Abschnitt 6). CZ-Tankpreise können manuell gepflegt werden.
- Der öffentliche OSRM-Demo-Server ist nur für geringe/private Nutzung gedacht — bei sehr
  häufiger Nutzung können Antwortzeiten schwanken. Für den privaten Gebrauch dieser App ist
  das im Rahmen der Kostenregel die einzige bekannte kostenlose Option ohne eigenen Server.
- Die Autobahn-GmbH-API deckt nur Bundesautobahnen (A-Straßen) ab; Bundes-/Landstraßen
  (B-, S-Straßen) liefern bewusst keine Ereignisse, statt „frei“ vorzutäuschen.
- Push-Benachrichtigungen funktionieren nur, während die App im Vordergrund/installiert
  aktiv ist — kein Hintergrund-Server, der proaktiv pusht (passend zur Kostenregel).
- Icons sind ein einfacher Platzhalter (Tacho-Symbol); jederzeit ersetzbar.

## Definition of Done — Phasenstatus

- [x] Phase 1.0 – Grundgerüst (PWA, Navigation, Design, IndexedDB, GitHub-Pages-tauglich)
- [x] Phase 2.0 – Karte (Leaflet + OpenStreetMap, Marker, Routen-Zeichnung, lazy-loaded)
- [x] Phase 3.0 – Eigene Strecken (voll funktionsfähiges CRUD, Ortssuche, Routenberechnung)
- [x] Phase 4.0 – Verkehr Deutschland (Autobahn GmbH API, Caching, Korridor-Filterung)
- [x] Phase 5.0 – Verkehr Tschechien (Recherche abgeschlossen, ehrlich dokumentiert: keine
      nutzbare kostenlose Quelle ohne eigenen Server gefunden)
- [x] Phase 6.0 – Tankstellen Deutschland (Tankerkönig, Suche, Favoriten, Preise, Caching)
- [x] Phase 7.0 – Tankstellen Tschechien (Recherche abgeschlossen; Fallback: manuelle
      Preiserfassung, Provider-Architektur für spätere Fuelo-Anbindung vorbereitet)
- [x] Phase 8.0 – Dashboard (alle Systeme zusammengeführt, Gesamtstatus-Berechnung)
- [x] Phase 9.0 – Offline/PWA (Service Worker, App-Shell-Cache, Offline-Kennzeichnung,
      Update-Erkennung)
- [x] Phase 10.0 – Backup/Import/Export (vollständig, inkl. Einstellungen, getestet)
- [x] Phase 11.0 – Performance & UX (Leaflet lazy-loaded, Nominatim debounced, kleine
      Bundle-Größe beim Start)
- [x] Phase 12.0 – Finale Version (End-to-End getestet mit gemockten echten API-Schemata:
      Streckenanlage, Statusberechnung inkl. Vollsperrung, Tankstellensuche/-favoriten,
      Bearbeiten/Löschen, Offline-Start, Backup-Restore, alles fehlerfrei)
